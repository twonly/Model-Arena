# Parametric Bookshelf

## Overview
Native Blender 5.2 parametric bookshelf built entirely from Blender primitive cubes (editable mesh objects). One script generates both the baseline and modified versions through command-line parameters; no separate geometry code is written per version.

## Deliverables
- `scripts/bookshelf.py` — parametric generator
- `blends/baseline.blend` — baseline project (reopenable)
- `blends/modified.blend` — modified project (reopenable)
- `json/baseline.json` — baseline parameter + object report
- `json/modified.json` — modified parameter + object report
- `images/baseline_main.png` — 1920x1080 baseline front view
- `images/baseline_back.png` — 1920x1080 baseline back view (real structure)
- `images/modified_main.png` — 1920x1080 modified front view
- `previews/` — low-resolution preview renders
- `logs/` — render log files

## Parameters (single shared mechanism)
`--width_mm --depth_mm --height_mm --thickness_mm --compartments --wood_color`

Same script and parameter mechanism produce both versions:
- Baseline: `--width_mm 800 --depth_mm 300 --height_mm 1200 --thickness_mm 18 --compartments 3`
- Modified: `--width_mm 1000 --depth_mm 300 --height_mm 1200 --thickness_mm 18 --compartments 4`

## Construction semantics
The bookcase exterior is exactly W × D × H. Two full-depth side panels (thickness × D × H) stand at the outer X boundaries. The top and bottom panels (W−2t × D × t) sit *between* the sides, so outer boundaries stay W × H. Internal shelves (W−2t × D × t) create N equal clear compartments.

Equal-gap layer semantics: clear compartment height g satisfies
`(N+1)·t + N·g = H  →  g = (H − (N+1)·t) / N`.
Each shelf panel bottom face sits at `z = i·(t + g)` for compartment i. The bottom panel occupies z∈[0,t]; each shelf panel occupies z∈[i·(t+g), i·(t+g)+t]; the top panel occupies z∈[H−t, H]. Thus every clear compartment is exactly g tall.

- Baseline (N=3): g = (1.2 − 4·0.018)/3 = 0.376 m per compartment.
- Modified (N=4): g = (1.2 − 5·0.018)/4 = 0.2775 m per compartment.

## Collections
- `Bookcase` — all shelf panels only (Side_Left, Side_Right, Bottom, Top, Shelf_1…). Independent named objects; editable; measurable.
- `Props` — display books only; excluded from Bookcase so it never affects measurement.

No back panel is modeled; the rear is the real rear faces of the side panels and shelf panels, so the back view shows actual editable structure — no background plane is used to fake it.

## Rendering
EEVEE, 1920×1080 PNG, sun + area fill lighting, neutral gray world. Camera aimed at bookcase center. Main view: front three-quarter. Back view: from +Y rear.

## Rebuild commands
```
blender --background --factory-startup --threads 2 --python scripts/bookshelf.py -- \
  --width_mm 800 --depth_mm 300 --height_mm 1200 --thickness_mm 18 --compartments 3 \
  --wood_color 8B5A3C --out_blend blends/baseline.blend --out_json json/baseline.json

blender --background --factory-startup --threads 2 --python scripts/bookshelf.py -- \
  --width_mm 1000 --depth_mm 300 --height_mm 1200 --thickness_mm 18 --compartments 4 \
  --wood_color 8B5A3C --out_blend blends/modified.blend --out_json json/modified.json
```

## Verification summary
- Both blends reopen in separate Blender background processes with Bookcase/Props collections, Wood/materials, Camera, Sun/Fill lights.
- Baseline exterior 0.8 × 0.3 × 1.2 m; 2 side + 4 horizontal panels; 3 equal clear compartments of 0.376 m; thickness 18 mm.
- Modified exterior 1.0 × 0.3 × 1.2 m; 2 side + 5 horizontal panels; 4 equal clear compartments of 0.2775 m; thickness 18 mm.
- Three required images at 1920×1080; back view shows real editable structure.
