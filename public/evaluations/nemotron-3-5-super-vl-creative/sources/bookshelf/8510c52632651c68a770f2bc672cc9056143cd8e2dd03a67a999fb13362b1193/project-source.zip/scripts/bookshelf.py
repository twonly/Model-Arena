"""Parametric Bookshelf - Blender 5.2 native geometry script.
Generates an editable wooden bookcase from native Blender cube meshes.
All panels independent objects, named individually, grouped in "Bookcase"
collection. No back panel (open-back); real geometry inspectable from back.
No background plane fakes the back.

Usage:
  blender --background --factory-startup --threads 2 --python scripts/bookshelf.py -- \
    --width_mm 800 --depth_mm 300 --height_mm 1200 --thickness_mm 18 \
    --compartments 3 --wood_color 8B5A3C --out_blend blends/baseline.blend \
    --out_json json/baseline.json --render main --resolution 1920x1080
"""
import argparse, json, math, os, sys
import bpy
from mathutils import Vector, Color

DEFAULTS = dict(width_mm=800.0, depth_mm=300.0, height_mm=1200.0,
                thickness_mm=18.0, compartments=3, wood_color="8B5A3C")

def mm(v):
    return v / 1000.0

def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Parametric bookshelf")
    p.add_argument("--width_mm", type=float, default=DEFAULTS["width_mm"])
    p.add_argument("--depth_mm", type=float, default=DEFAULTS["depth_mm"])
    p.add_argument("--height_mm", type=float, default=DEFAULTS["height_mm"])
    p.add_argument("--thickness_mm", type=float, default=DEFAULTS["thickness_mm"])
    p.add_argument("--compartments", type=int, default=DEFAULTS["compartments"])
    p.add_argument("--wood_color", type=str, default=DEFAULTS["wood_color"])
    p.add_argument("--out_blend", type=str, required=True)
    p.add_argument("--out_json", type=str, required=True)
    p.add_argument("--render", type=str, default="none", choices=["none","main","back"])
    p.add_argument("--resolution", type=str, default="1920x1080")
    p.add_argument("--camera", type=str, default="main", choices=["main","back"])
    return p.parse_args(argv)

def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for coll in list(bpy.data.collections):
        bpy.data.collections.remove(coll)
    for mat in list(bpy.data.materials):
        bpy.data.materials.remove(mat)
    for mesh in list(bpy.data.meshes):
        bpy.data.meshes.remove(mesh)

def ensure_collection(name):
    if name in bpy.data.collections:
        return bpy.data.collections[name]
    coll = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(coll)
    return coll

def add_panel(name, sx, sy, sz, cx, cy, cz, collection, material):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(cx, cy, cz))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (sx, sy, sz)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    collection.objects.link(obj)
    for coll in list(obj.users_collection):
        if coll.name != collection.name:
            coll.objects.unlink(obj)
    if material:
        obj.data.materials.append(material)
    return obj

def make_wood_material(name, hex_color):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    rgb = nodes.new("ShaderNodeRGB")
    c = Color()
    hc = hex_color if hex_color.startswith("#") else "#" + hex_color
    hc = hc.lstrip("#")
    c.r = int(hc[0:2], 16) / 255.0
    c.g = int(hc[2:4], 16) / 255.0
    c.b = int(hc[4:6], 16) / 255.0
    rgb.outputs["Color"].default_value = (c.r, c.g, c.b, 1.0)
    bsdf.inputs["Base Color"].default_value = (c.r, c.g, c.b, 1.0)
    if "Roughness" in bsdf.inputs:
        bsdf.inputs["Roughness"].default_value = 0.75
    if "Specular" in bsdf.inputs:
        bsdf.inputs["Specular"].default_value = 0.15
    if "IOR" in bsdf.inputs:
        bsdf.inputs["IOR"].default_value = 1.45
    links.new(rgb.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    mat.diffuse_color = (c.r, c.g, c.b, 1.0)
    return mat

def build_bookshelf(W, D, H, t, compartments, wood_color, collection, material):
    panels = []
    shelf_w = W - 2.0 * t
    # Equal clear compartment gaps g between the (N+1) horizontal panels:
    #   (N+1)*t + N*g = H  ->  g = (H - (N+1)*t) / N
    g = (H - (compartments + 1) * t) / compartments
    pitch = t + g
    def rec(name, kind, sx, sy, sz, cx, cy, cz):
        add_panel(name, sx, sy, sz, cx, cy, cz, collection, material)
        panels.append(dict(name=name, kind=kind,
                           location=[cx, cy, cz], dimensions=[sx, sy, sz]))
    rec("Side_Left", "side", t, D, H, t/2.0, 0.0, H/2.0)
    rec("Side_Right", "side", t, D, H, W - t/2.0, 0.0, H/2.0)
    rec("Bottom", "horizontal", shelf_w, D, t, W/2.0, 0.0, t/2.0)
    rec("Top", "horizontal", shelf_w, D, t, W/2.0, 0.0, H - t/2.0)
    for i in range(1, compartments):
        z_bottom = i * pitch
        z_center = z_bottom + t / 2.0
        rec("Shelf_%d" % i, "horizontal", shelf_w, D, t, W/2.0, 0.0, z_center)
    return panels

def add_cube_props(name, size, location, collection, material):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    collection.objects.link(obj)
    for coll in list(obj.users_collection):
        if coll.name != collection.name:
            coll.objects.unlink(obj)
    if material:
        obj.data.materials.append(material)
    return obj

def add_books(W, D, H, t, N, props):
    net_h = H - 2.0 * t
    c_h = net_h / N
    book_depth = 0.22 * D
    book_w = 0.045
    gap = 0.012
    book_h = c_h * 0.85
    x = t + 0.01
    y = -D / 2.0 + 0.02
    z0 = t
    for i, (bname, bhex) in enumerate([
        ("Book_Red","C0392B"),("Book_Blue","2E86C1"),
        ("Book_Green","27AE60"),("Book_Yellow","F1C40F")]):
        if x + book_w > W - t - 0.01:
            break
        bmat = make_wood_material(bname, bhex)
        add_cube_props(bname, Vector((book_w, book_depth, book_h)),
                       Vector((x + book_w/2.0, y, z0 + book_h/2.0)), props, bmat)
        x += book_w + gap

def add_camera(name, location, target):
    cam_data = bpy.data.cameras.new(name)
    cam_data.lens = 35.0
    cam = bpy.data.objects.new(name, cam_data)
    cam.location = location
    direction = (target - location).normalized()
    cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.collection.objects.link(cam)
    return cam

def setup_scene(W, D, H, mode):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    world = bpy.data.worlds["World"]
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs["Color"].default_value = (0.18, 0.18, 0.19, 1.0)
        bg.inputs["Strength"].default_value = 1.0
    for o in list(scene.objects):
        if o.type in ("CAMERA", "LIGHT"):
            scene.objects.unlink(o)
            bpy.data.objects.remove(o)
    center = Vector((W / 2.0, 0.0, H / 2.0))
    span = max(W, D, H)
    add_camera("Camera_Main", Vector((-W * 2.5, -D * 3.2, H * 0.75)), center)
    add_camera("Camera_Back", Vector((W / 2.0, D + span * 1.9, H / 2.0)), center)
    scene.camera = bpy.data.objects["Camera_Main"]
    sun = bpy.data.lights.new("Sun", "SUN")
    sun.energy = 4.0
    sun.color = (1.0, 0.96, 0.90)
    so = bpy.data.objects.new("Sun", sun)
    so.location = Vector((W * 0.6, -D * 0.8, H * 1.4))
    bpy.context.scene.collection.objects.link(so)
    fill = bpy.data.lights.new("Fill", "AREA")
    fill.energy = 600.0
    fill.size = 5.0
    fill.color = (0.92, 0.94, 1.0)
    fo = bpy.data.objects.new("Fill", fill)
    fo.location = Vector((-W * 0.5, D * 0.6, H * 0.7))
    fo.rotation_euler = (math.radians(-45), math.radians(45), 0.0)
    bpy.context.scene.collection.objects.link(fo)

def set_resolution(w, h):
    sc = bpy.context.scene
    sc.render.resolution_x = w
    sc.render.resolution_y = h
    sc.render.resolution_percentage = 100

def write_json(path, params, panels, exterior):
    report = {"parameters": params, "exterior_dimensions_m": exterior,
              "panel_count": len(panels), "panels": panels}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

def main(argv=None):
    args = parse_args(argv)
    W = mm(args.width_mm)
    D = mm(args.depth_mm)
    H = mm(args.height_mm)
    t = mm(args.thickness_mm)
    N = max(1, int(args.compartments))
    clear_scene()
    bookcase = ensure_collection("Bookcase")
    props = ensure_collection("Props")
    mat = make_wood_material("Wood", args.wood_color)
    panels = build_bookshelf(W, D, H, t, N, args.wood_color, bookcase, mat)
    add_books(W, D, H, t, N, props)
    setup_scene(W, D, H, args.camera)
    scene = bpy.context.scene
    if args.camera == "back":
        scene.camera = bpy.data.objects["Camera_Back"]
    else:
        scene.camera = bpy.data.objects["Camera_Main"]
    exterior = [W, D, H]
    write_json(args.out_json, dict(width_mm=args.width_mm,
        depth_mm=args.depth_mm, height_mm=args.height_mm,
        thickness_mm=args.thickness_mm, compartments=N,
        wood_color=args.wood_color), panels, exterior)
    d = os.path.dirname(args.out_blend)
    if d:
        os.makedirs(d, exist_ok=True)
    bpy.ops.wm.save_mainfile(filepath=args.out_blend)
    if args.render != "none":
        sc = bpy.context.scene
        rw, rh = [int(v) for v in args.resolution.split("x")]
        set_resolution(rw, rh)
        out_png = args.out_json.rsplit(".", 1)[0] + "_" + args.render + ".png"
        sc.render.filepath = out_png
        bpy.ops.render.render(write_still=True)
        print("RENDERED", out_png)
    print("DONE blend=%s json=%s panels=%d exterior=%s camera=%s" % (
        args.out_blend, args.out_json, len(panels), exterior, args.camera))

if __name__ == "__main__":
    if "--" in sys.argv:
        main(sys.argv[sys.argv.index("--") + 1:])
    else:
        main()
