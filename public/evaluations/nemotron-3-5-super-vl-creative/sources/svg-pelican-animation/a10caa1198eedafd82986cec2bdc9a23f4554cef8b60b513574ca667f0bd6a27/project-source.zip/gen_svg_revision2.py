import math

# ---------- Geometry (symmetric, non-degenerate IK) ----------
W,H = 800,600
GROUND = 440.0                      # wheel bottoms tangent to ground
WHUB = 370.0                        # r=70 -> bottom 440, top 300
REAR = (250.0, WHUB); FRONT = (530.0, WHUB)
BB   = (350.0, 355.0)               # bottom bracket, centered under body
CR   = 35.0                         # crank radius
THIGH, SHIN = 52.0, 56.0            # reach 108
HL   = (315.0, 322.0)               # left hip (inside body, near left side)
HR   = (385.0, 322.0)               # right hip (inside body, near right side)

def pedal_offset(leg, t):
    ph = math.radians(360.0*t)
    if leg == 'left':
        return (-CR*math.sin(ph), +CR*math.cos(ph))   # LEFT pedal DOWN at t=0
    else:
        return ( CR*math.sin(ph), -CR*math.cos(ph))   # RIGHT pedal UP at t=0

def pedal_world(leg, t):
    ox,oy = pedal_offset(leg,t)
    return (BB[0]+ox, BB[1]+oy)

def ik(H, P, a, b, side):
    dx=P[0]-H[0]; dy=P[1]-H[1]
    dist=math.hypot(dx,dy)
    d=max(abs(a-b), min(a+b, dist))
    base=math.atan2(dy,dx)
    c=(a*a+d*d-b*b)/(2*a*d); c=max(-1.0,min(1.0,c))
    gamma=math.acos(c)
    ang=base+side*gamma
    return (H[0]+a*math.cos(ang), H[1]+a*math.sin(ang))

SIDE={'left':-1.0,'right':+1.0}
N=16
keyTimes=[i/N for i in range(N+1)]
frames={}
for leg,hip in (('left',HL),('right',HR)):
    frames[leg]=[]
    for kt in keyTimes:
        frames[leg].append((ik(hip, pedal_world(leg,kt), THIGH, SHIN, SIDE[leg]),
                            pedal_world(leg,kt)))

print("=== IK & contact verification ===")
allok=True
for leg,hip in (('left',HL),('right',HR)):
    jumps=0; maxd=0; mind=1e9
    for i in range(1,N+1):
        jumps += math.hypot(frames[leg][i][0][0]-frames[leg][i-1][0][0],
                            frames[leg][i][0][1]-frames[leg][i-1][0][1]) > 12
    for kt in keyTimes:
        P=pedal_world(leg,kt); d=math.hypot(P[0]-hip[0],P[1]-hip[1])
        maxd=max(maxd,d); mind=min(mind,d)
    print(f"{leg:5s} hip-pedal dist [{mind:.2f},{maxd:.2f}] reach={THIGH+SHIN} knee_jumps>{12}px={jumps}")
    if mind<15 or maxd>THIGH+SHIN or jumps>0: allok=False
xs=[];ys=[]
for leg in frames:
    for (K,P) in frames[leg]: xs+=[K[0],P[0]]; ys+=[K[1],P[1]]
print("knee/pedal x:",round(min(xs),1),round(max(xs),1)," y:",round(min(ys),1),round(max(ys),1))
print("canvas OK:", min(xs)>=0 and max(xs)<=800 and min(ys)>=0 and max(ys)<=600)

def f(v): return f"{v:.2f}"
svg=[]
svg.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" xmlns:xlink="http://www.w3.org/1999/xlink">')
svg.append(f'  <rect width="{W}" height="{H}" fill="#eef4ea"/>')
svg.append(f'  <line x1="0" y1="{GROUND}" x2="{W}" y2="{GROUND}" stroke="#8a9e7c" stroke-width="4"/>')

def wheel(cx,cy,gid,spokes_gid):
    svg.append(f'  <g id="{gid}">')
    svg.append(f'    <circle cx="{f(cx)}" cy="{f(cy)}" r="70" fill="none" stroke="#222" stroke-width="14"/>')
    svg.append(f'    <circle cx="{f(cx)}" cy="{f(cy)}" r="62" fill="none" stroke="#444" stroke-width="2"/>')
    svg.append(f'    <g id="{spokes_gid}">')
    for ang in range(0,360,30):
        x2=cx+62*math.cos(math.radians(ang)); y2=cy+62*math.sin(math.radians(ang))
        svg.append(f'      <line x1="{f(cx)}" y1="{f(cy)}" x2="{f(x2)}" y2="{f(y2)}" stroke="#555" stroke-width="2"/>')
    svg.append('    </g>')
    svg.append(f'    <circle cx="{f(cx)}" cy="{f(cy)}" r="10" fill="#333"/>')
    svg.append('  </g>')
wheel(*REAR,"rear-wheel","rear-spokes")
wheel(*FRONT,"front-wheel","front-spokes")

svg.append('  <g id="frame" stroke="#c0392b" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">')
svg.append(f'    <line x1="{f(REAR[0])}" y1="{f(REAR[1])}" x2="{f(BB[0])}" y2="{f(BB[1])}"/>')   # chain stay
svg.append('    <line x1="285" y1="322" x2="350" y2="292"/>')        # seat tube saddle->BB zone
svg.append('    <line x1="350" y1="292" x2="470" y2="300"/>')        # top tube
svg.append(f'    <line x1="470" y1="300" x2="{f(BB[0])}" y2="{f(BB[1])}"/>')  # down tube
svg.append(f'    <line x1="{f(FRONT[0])}" y1="{f(FRONT[1])}" x2="470" y2="300"/>')  # fork
svg.append('  </g>')
svg.append(f'  <circle cx="{f(BB[0])}" cy="{f(BB[1])}" r="8" fill="#555"/>')

# crank + pedals + FEET (feet locked to pedals: drawn at pedal offsets inside rotating group)
svg.append('  <g id="crank">')
svg.append(f'    <animateTransform attributeName="transform" type="rotate"')
svg.append(f'      from="0 {f(BB[0])} {f(BB[1])}" to="360 {f(BB[0])} {f(BB[1])}" dur="4s" repeatCount="indefinite"/>')
svg.append(f'    <line x1="{f(BB[0])}" y1="{f(BB[1])}" x2="{f(BB[0])}" y2="{f(BB[1]-CR)}" stroke="#666" stroke-width="6" stroke-linecap="round"/>')
svg.append(f'    <line x1="{f(BB[0])}" y1="{f(BB[1])}" x2="{f(BB[0])}" y2="{f(BB[1]+CR)}" stroke="#666" stroke-width="6" stroke-linecap="round"/>')
svg.append(f'    <circle cx="{f(BB[0])}" cy="{f(BB[1]-CR)}" r="7" fill="#999"/>')   # top pedal
svg.append(f'    <circle cx="{f(BB[0])}" cy="{f(BB[1]+CR)}" r="7" fill="#999"/>')   # bottom pedal
svg.append(f'    <circle id="foot-right" cx="{f(BB[0])}" cy="{f(BB[1]-CR)}" r="6" fill="#333"/>')   # foot ON top pedal
svg.append(f'    <circle id="foot-left"  cx="{f(BB[0])}" cy="{f(BB[1]+CR)}" r="6" fill="#333"/>')   # foot ON bottom pedal
svg.append('  </g>')

# pelican
svg.append('  <g id="pelican">')
svg.append('    <ellipse cx="350" cy="300" rx="40" ry="28" fill="#e8e8e8"/>')   # body; hips sit on/near bottom edge y=322
svg.append('    <path d="M 350 282 Q 372 272 372 238 Q 370 222 356 222" fill="none" stroke="#e8e8e8" stroke-width="20" stroke-linecap="round"/>')  # neck
svg.append('    <circle cx="372" cy="255" r="14" fill="#e8e8e8"/>')           # head
svg.append('    <path d="M 384 254 L 470 248 L 474 262 L 388 268 Z" fill="#f0e68c" stroke="#b89b3c" stroke-width="1"/>')  # long bill
svg.append('    <path d="M 378 262 Q 395 278 430 272 Q 455 268 468 262 Q 462 256 448 254 Q 410 258 382 260 Z" fill="#f5deb3" stroke="#d2b48c" stroke-width="1"/>')  # pouch connected to bill/head
svg.append('    <circle cx="368" cy="251" r="2" fill="#222"/>')               # eye
svg.append('    <ellipse cx="360" cy="306" rx="17" ry="13" fill="#d8d8d8" transform="rotate(-15 360 306)"/>')  # wing

for leg,hip in (('left',HL),('right',HR)):
    kts="; ".join(f"{i/N:.4f}" for i in range(N+1))
    dvals="; ".join(f"M {hip[0]:.2f} {hip[1]:.2f} L {k[0]:.2f} {k[1]:.2f} L {p[0]:.2f} {p[1]:.2f}" for (k,p) in frames[leg])
    first_d=dvals.split("; ")[0]
    svg.append(f'    <path id="leg-{leg}" d="{first_d}" stroke="#5a3e36" stroke-width="7" stroke-linecap="round" fill="none"/>')
    svg.append(f'    <animate xlink:href="#leg-{leg}" attributeName="d" dur="4s" repeatCount="indefinite" calcMode="linear" keyTimes="{kts}" values="{dvals}"/>')
    svg.append(f'    <circle id="knee-{leg}" cx="{frames[leg][0][0][0]:.2f}" cy="{frames[leg][0][0][1]:.2f}" r="5" fill="#5a3e36"/>')
    svg.append(f'    <animate xlink:href="#knee-{leg}" attributeName="cx" dur="4s" repeatCount="indefinite" calcMode="linear" keyTimes="{kts}" values="{"; ".join(f"{k[0]:.2f}" for k,p in frames[leg])}"/>')
    svg.append(f'    <animate xlink:href="#knee-{leg}" attributeName="cy" dur="4s" repeatCount="indefinite" calcMode="linear" keyTimes="{kts}" values="{"; ".join(f"{k[1]:.2f}" for k,p in frames[leg])}"/>')
svg.append('  </g>')

svg.append('  <path d="M 290 320 Q 315 305 340 320" fill="none" stroke="#444" stroke-width="9" stroke-linecap="round"/>')  # saddle
svg.append(f'  <line x1="315" y1="322" x2="315" y2="292" stroke="#666" stroke-width="5" stroke-linecap="round"/>')          # seat post
svg.append('  <line x1="470" y1="300" x2="470" y2="270" stroke="#666" stroke-width="5" stroke-linecap="round"/>')          # handlebar post
svg.append('  <path d="M 450 266 Q 470 260 490 266" fill="none" stroke="#444" stroke-width="8" stroke-linecap="round"/>')  # handlebar

svg.append(f'  <animateTransform xlink:href="#rear-wheel" attributeName="transform" type="rotate" from="0 {f(REAR[0])} {f(REAR[1])}" to="360 {f(REAR[0])} {f(REAR[1])}" dur="4s" repeatCount="indefinite"/>')
svg.append(f'  <animateTransform xlink:href="#front-wheel" attributeName="transform" type="rotate" from="0 {f(FRONT[0])} {f(FRONT[1])}" to="360 {f(FRONT[0])} {f(FRONT[1])}" dur="4s" repeatCount="indefinite"/>')

svg.append('  <text x="400" y="56" text-anchor="middle" fill="#444" font-family="Arial" font-size="22" font-weight="bold">Pelican on a Bicycle</text>')
svg.append('  <text x="400" y="584" text-anchor="middle" fill="#666" font-family="Arial" font-size="13">4-second seamless SMIL loop &#8226; rotating wheels &amp; crank &#8226; feet locked to pedals</text>')
svg.append('</svg>')

open('pelican_bicycle_revision-2.svg','w').write("\n".join(svg))
print("\nwritten pelican_bicycle_revision-2.svg | IK robust:", allok)
